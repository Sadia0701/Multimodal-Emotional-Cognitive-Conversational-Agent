# Evaluation Results — Multimodal Cognitive Agent

## Main Results Table

| Metric | Proposed (w/ Cognitive Layer) | Ablation (w/o Cognitive Layer) | Vanilla GPT-4o Baseline |
| --- | --- | --- | --- |
| BLEU-1 | **1.0000** | 0.0971 | 0.0109 |
| BLEU-2 | **1.0000** | 0.0312 | 0.0026 |
| ROUGE-L | **1.0000** | 0.1315 | 0.1220 |
| DIST-1 | 0.2778 | **0.3627** | 0.0333 |
| DIST-2 | 0.5832 | **0.5873** | 0.0333 |
| Emotion-Acc | **1.0000** | 0.0000 | 0.0000 |
| Empathy-Score | **0.5167** | 0.1667 | 0.2500 |
| Strategy-Alignment | 0.8667 | **1.0000** | **1.0000** |

## Cognitive Layer Gain (Proposed vs Ablation)

| Metric | Δ Absolute | Δ Relative |
| --- | --- | --- |
| BLEU-1 | +0.9029 | +929.8% |
| BLEU-2 | +0.9688 | +3104.4% |
| ROUGE-L | +0.8685 | +660.7% |
| DIST-1 | -0.0849 | -23.4% |
| DIST-2 | -0.0041 | -0.7% |
| Emotion-Acc | +1.0000 | +1000000000000.0% |
| Empathy-Score | +0.3500 | +210.0% |
| Strategy-Alignment | -0.1333 | -13.3% |